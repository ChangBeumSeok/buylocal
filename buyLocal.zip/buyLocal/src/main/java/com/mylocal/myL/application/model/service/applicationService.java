package com.mylocal.myL.application.model.service;

import com.mylocal.myL.application.model.vo.Product;

public interface applicationService{

	// 상품 등록
	public int insertProduct(Product p);
	
	
}
 