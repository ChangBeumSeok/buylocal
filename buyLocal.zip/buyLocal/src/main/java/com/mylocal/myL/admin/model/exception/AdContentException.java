package com.mylocal.myL.admin.model.exception;

public class AdContentException extends RuntimeException{
	public AdContentException(String msg) {
		super(msg);
	}
}
