package com.mylocal.myL.admin.model.exception;

public class AdUserException extends RuntimeException{
	public AdUserException(String msg) {
		super(msg);
	}
}
