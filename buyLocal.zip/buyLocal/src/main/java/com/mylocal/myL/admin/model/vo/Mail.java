package com.mylocal.myL.admin.model.vo;

public class Mail {

}
