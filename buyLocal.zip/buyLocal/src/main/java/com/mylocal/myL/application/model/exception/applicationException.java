package com.mylocal.myL.application.model.exception;

public class applicationException extends RuntimeException {
	
	public applicationException (String msg) {
		super(msg);
	}
}
 