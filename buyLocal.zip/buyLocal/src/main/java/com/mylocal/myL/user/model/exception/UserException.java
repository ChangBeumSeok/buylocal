package com.mylocal.myL.user.model.exception;

public class UserException extends RuntimeException{
	public UserException(String msg) {
		super(msg);
	}
}
