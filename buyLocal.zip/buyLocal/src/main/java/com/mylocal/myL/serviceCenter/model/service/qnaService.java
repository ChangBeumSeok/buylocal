package com.mylocal.myL.serviceCenter.model.service;

import com.mylocal.myL.serviceCenter.model.vo.QNA;

public interface qnaService{

	// QNA 제출 
	public int insertQNA(QNA q);
	
	
	
}
 