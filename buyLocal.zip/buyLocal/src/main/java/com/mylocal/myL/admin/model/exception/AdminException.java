package com.mylocal.myL.admin.model.exception;

public class AdminException extends RuntimeException{
	public AdminException(String msg) {
		super(msg);
	}
}
