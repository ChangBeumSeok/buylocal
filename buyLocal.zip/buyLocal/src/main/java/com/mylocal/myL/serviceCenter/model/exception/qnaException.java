package com.mylocal.myL.serviceCenter.model.exception;

public class qnaException extends RuntimeException {
	
	public qnaException (String msg) {
		super(msg);
	}
}
  