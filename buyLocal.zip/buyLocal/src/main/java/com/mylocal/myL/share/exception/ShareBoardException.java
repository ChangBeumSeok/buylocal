package com.mylocal.myL.share.exception;

public class ShareBoardException extends RuntimeException{
	public ShareBoardException(String msg) {
		super(msg);
	}
}
